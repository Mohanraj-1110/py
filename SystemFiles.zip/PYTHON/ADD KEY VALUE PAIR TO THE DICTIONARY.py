# ADD KEY VALUE PAIR TO THE DICTIONARY- 24/07/26

d={}

n=int(input("Enter No.of Key Value Pair To Get :"))

for _ in range(n):
    x=int(input("Enter Key :"))
    y=int(input("Enter Value :"))

    d.update({x:y})

print("Updated Dictionary:",d)
print("Sum of Key :",sum(d.keys()))
print("Sum of Values :",sum(d.values()))
