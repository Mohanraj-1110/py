# BASIC BANK TRANSACTION (OOPS) - 07/08/26


import sys
class Bank:
    def input(self):
        self.accno=int(input("Enter Account Number :"))
        self.bal=float(input("Enter Balance :"))
        self.cusname=input("Enter Customer Name :")

    def deposit(self):
        self.damt=float(input("Enter Deposit Amount :"))
        self.bal += self.damt

    def withdraw(self):
        self.wamt=float(input("Enter Withdraw Amount :"))
        if self.bal >= self.wamt:
            self.bal -= self.wamt
            print("Withraw Amount Successfully !!!")

        else:
            print("Insufficient Balance !!!")

    def display(self):
        print("Account No. :",self.accno,"\nCustomer Name :",self.cusname,"\nBalance :",self.bal)

b=Bank()
while True:
    ch=int(input("Enter Choice :"))
    if ch == 1:
        b.input()
    elif ch == 2:
        b.deposit()
    elif ch == 3:
        b.withdraw()
    elif ch == 4:
        b.display()
    else:
        sys.exit()
