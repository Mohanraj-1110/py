# PRIME FACTOR OF THE GIVEN NUMBER - 16/07/26

import math
n=int(input("ENTER an Integer :"))
print("FACTORS ARE :")
print(1)

while n%2 ==0:
    print(2)
    n=n//2

for i in range(3,int(math.sqrt(n)+1),2):
    while n%i==0:
        print(i)
        n=n//i

if n>2:
    print(n)
