# PALINDROME- 24/07/26

s=input("Enter String :")
rs=s[::-1]


print("The given String :",s)

if s==rs:
    print("The given String is Palindrome !!!")
else:
    print("The given String Not a Palindrome !!!")
