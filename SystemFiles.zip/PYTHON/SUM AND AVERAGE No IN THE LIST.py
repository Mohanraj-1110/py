# SUM AND AVERAGE OF NUMBERS IN THE LIST - 16/07/26

n=int(input("Enter Number of Elements in a List :"))
lst=[]
for i in range(n):
    x=int(input("Enter The Value of x :"))
    lst.append(x)

Sum=0
for i in range(n):
    Sum+=lst[i]

avg=Sum/n
print("Sum of n Numbers :",Sum)
print("Average of n Numbers :",round(avg,2))
