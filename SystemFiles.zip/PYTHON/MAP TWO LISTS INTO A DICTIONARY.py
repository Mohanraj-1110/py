# MAP TWO LISTS INTO A DICTIONARY- 24/07/26

rollno=[]
name=[]
d={}

n=int(input("Enter No.of Element :"))

print("FOR ROLL NUMBER !!!")
for i in range(n):
    x=input("Enter Roll No. :"+str(i+1)+":")
    rollno.append(x)
print("Roll Number :",rollno)

print("FOR NAME !!!")
for i in range(n):
    x=input("Enter Name :"+str(i+1)+":")
    name.append(x)
print("Name :",name)

d=dict(zip(rollno,name))
print("The Dictionary is:",d)

