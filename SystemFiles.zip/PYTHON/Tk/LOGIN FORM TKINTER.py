
from tkinter import *
from functools import partial
from tkinter import messagebox
import sqlite3
import  sys

def  validate(username, password):
        conn = sqlite3.connect('data.db')
        cursor = conn.cursor()
        data=cursor.execute("SELECT * FROM LOGIN")
        flag=0
        for rec in data:
                #print(rec)
                if rec[0]==username.get() and rec[1]==password.get():
                        flag=1
                        break
        if flag==1:
                msg=messagebox.showinfo( "Validation", "login successfully")
        else:
                msg=messagebox.showinfo( "Validation", "Invalid username/password")             
        return
    
def cancelbut():
        tkWindow.destroy()

tkWindow = Tk()  
tkWindow.geometry('400x150')  
tkWindow.title('Tkinter Login Form')
usernameLabel = Label(tkWindow, text="User Name").grid(row=0, column=0)
username = StringVar()
usernameEntry = Entry(tkWindow, textvariable=username).grid(row=0, column=1)  

passwordLabel = Label(tkWindow,text="Password").grid(row=1, column=0)  
password = StringVar()
passwordEntry = Entry(tkWindow, textvariable=password, show='*').grid(row=1, column=1)                                                               

loginbut = partial(validate, username, password)
loginButton = Button(tkWindow, text="Login",command=loginbut).grid(row=4, column=0)

cancelbut = partial(cancelbut)
cancel= Button(tkWindow, text="cancel",command=cancelbut).grid(row=4, column=1)
tkWindow.mainloop()
