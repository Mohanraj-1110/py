from tkinter import *
from functools import partial
import sqlite3
import  sys

def add(n1,n2):
    x=int(n1.get())+int(n2.get())
    r.set(str(x))
def sub(n1,n2):
    x=int(n1.get())-int(n2.get())
    r.set(str(x))
def floordiv(n1,n2):
    x=int(n1.get())//int(n2.get())
    r.set(str(x))
def mul(n1,n2):
    x=int(n1.get())*int(n2.get())
    r.set(str(x))
def divide(n1,n2):
    x=int(n1.get())/int(n2.get())
    r.set(str(x))
def expo(n1,n2):
    x=int(n1.get())**int(n2.get())
    r.set(str(x))


tkWindow = Tk()  
tkWindow.geometry('400x400')  
tkWindow.title('Arithmetic calculator')
 
n1label = Label(tkWindow,text="Num 1").grid(row=0,column=0)
n1 = StringVar()
n1Entry = Entry(tkWindow,textvariable=n1).grid(row=0, column=1)

n2label = Label(tkWindow,text="Num 2").grid(row=1,column=0)
n2 = StringVar()
n2Entry = Entry(tkWindow,textvariable=n2).grid(row=1, column=1)  

reslabel = Label(tkWindow,text="Result").grid(row=2,column=0)
r = StringVar()
resEntry = Entry(tkWindow,textvariable=r).grid(row=2, column=1)


add = partial(add,n1,n2)
addButton = Button(tkWindow,text="Add",command=add).grid(row=5, column=0)

sub = partial(sub,n1,n2)
subButton= Button(tkWindow,text="Sub",command=sub).grid(row=5, column=1)

div = partial(divide,n1,n2)
divButton = Button(tkWindow,text="Divide",command=div).grid(row=5, column=2)

mul = partial(mul,n1,n2)
mulButton= Button(tkWindow,text="Mul",command=mul).grid(row=6, column=0)

fdiv= partial(floordiv,n1,n2)
fdivButton = Button(tkWindow,text="FloorDiv",command=fdiv).grid(row=6, column=1)

expo= partial(expo,n1,n2)
expoButton= Button(tkWindow,text="Expo",command=expo).grid(row=6, column=2)

tkWindow.mainloop()
