import sqlite3

conn = sqlite3.connect("student_marks.db")
cursor = conn.cursor()


def calculate_total_and_avg(m1, m2, m3):
    total = m1 + m2 + m3
    avg = total / 3
    return total, avg


choice = 1

while choice <= 5:
    choice = int(input("\nEnter your choice: "))

    if choice == 1:
        sql = '''
        CREATE TABLE IF NOT EXISTS students (
            roll_no INT PRIMARY KEY NOT NULL,
            name CHAR(50),
            m1 INT,
            m2 INT,
            m3 INT,
            total INT,
            average FLOAT
        )
        '''
        cursor.execute(sql)
        print("Table created successfully.")
        conn.commit()

    elif choice == 2:
        n = int(input("Enter the number of student records to be added: "))

        for i in range(n):
            roll_no = int(input("Enter roll number: "))
            name = input("Enter student name: ")
            m1 = int(input("Enter marks for subject M1: "))
            m2 = int(input("Enter marks for subject M2: "))
            m3 = int(input("Enter marks for subject M3: "))

            total, avg = calculate_total_and_avg(m1, m2, m3)

            sql = '''
            INSERT INTO students
            (roll_no, name, m1, m2, m3, total, average)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            '''

            data = (roll_no, name, m1, m2, m3, total, avg)
            cursor.execute(sql, data)

            print("Record for {name} inserted successfully.")

        conn.commit()

    elif choice == 3:
        rec = cursor.execute("SELECT * FROM students")
        rows = rec.fetchall()

        for row in rows:
            print(row)

    elif choice == 4:
        rec = cursor.execute("SELECT * FROM students")
        rows = rec.fetchall()

        for row in rows:
            roll_no = row[0]
            m1 = row[2]
            m2 = row[3]
            m3 = row[4]

            total, avg = calculate_total_and_avg(m1, m2, m3)

            sql = '''
            UPDATE students
            SET total = ?, average = ?
            WHERE roll_no = ?
            '''

            cursor.execute(sql, (total, avg, roll_no))

            print("Record for roll no {roll_no} \n updated successfully.")

        conn.commit()

    elif choice == 5:
        roll_no = int(
            input("Enter the roll number of the student to be deleted: ")
        )

        sql = "DELETE FROM students WHERE roll_no = ?"
        cursor.execute(sql, (roll_no,))

        conn.commit()
        print("Record deleted successfully.")

    else:
        print("Invalid choice.")

conn.close()
