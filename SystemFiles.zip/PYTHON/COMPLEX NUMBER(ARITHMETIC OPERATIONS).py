# ARITHMETIC OPERATIONS OF COMPLEX NUMBER - 07/08/26

import sys
class Complex:
    def input(self):
        self.a=complex(input("Enter Complex Number :"))
        self.b=complex(input("Enter Complex Number :"))

    def add(self):
        print("ADDITION :",self.a+self.b)

    def sub(self):
        print("SUBTRACTION :",self.a-self.b)

    def mul(self):
        print("MULTIPLICATION :",self.a*self.b)

    def div(self):
        print("DIVISION :",self.a/self.b)

c=Complex()
while True:
     ch=int(input("Enter Choice :"))
     if ch == 1:
         c.input()
     elif ch == 2:
         c.add()
     elif ch == 3:
         c.sub()
     elif ch == 4:
         c.mul()
     elif ch == 5:
         c.div()
     else:
         sys.exit()
