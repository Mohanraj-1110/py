# REMOVE DUPLICATE ELEMENTS IN THE LIST - 17/07/26

n=int(input("Enter Number of Elements in a List :"))
lst=[]
for i in range(n):
    x=int(input("Enter The Value of x :"))
    lst.append(x)

print("Duplicate List :",lst)
flst=[]
for i in lst:
    if i not in flst:
        flst.append(i)

print("After Removing Duplicates :",flst)

#Repitition Count

for i in flst:
    count=0
    count1=lst.count(i)
    print(i,"Count :",count1)
    for j in lst:
        if i==j:
            count +=1
    print(i,"Count :",count)
