class stud:
    def get1(self):
        self.no = int(input("Enter roll no: "))
        self.name = input("Enter the Name: ")
class marks(stud):
    def get2(self):
        self.m1 = int(input("Mark 1: "))
        self.m2 = int(input("Mark 2: "))
    def process(self):
        self.total = self.m1 + self.m2
        self.avg = self.total / 2.0
class sports(marks):
    def get3(self):
        self.sport = input("Enter sport: ")
    def display(self):
        print("Rollno:", self.no, "\tName:", self.name)
        print("Mark1:", self.m1, "\tMark2:", self.m2)
        print("Total:", self.total, "\tAvg:", self.avg)
        print("Sports Name:", self.sport)
s = sports()
s.get1()
s.get2()
s.process()
s.get3()
s.display()

