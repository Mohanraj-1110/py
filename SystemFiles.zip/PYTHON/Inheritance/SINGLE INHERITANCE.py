class A:
    def getname(self):
        self.name = input("Enter name:")
class B(A):
    def getsalary(self):
        self.sal = int(input("Enter salary:"))
    def printdetails(self):
        print("Name:", self.name)
        print("Salary:", self.sal)
obj = B()
obj.getname()
obj.getsalary()
obj.printdetails()
