# SWAP TWO VALUES IN A LIST - 17/07/26

n=int(input("Enter Number of Elements in a List :"))
lst=[]
for i in range(n):
    x=int(input("Enter The Value of x :"))
    lst.append(x)

print("Before Exchange :",lst)

p1=int(input("Enter the Position 1 :"))
p2=int(input("Enter the Position 2 :"))

lst[p1],lst[p2]=lst[p2],lst[p1]

print("After Exchange :",lst)
