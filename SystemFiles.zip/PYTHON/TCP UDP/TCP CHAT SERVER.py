# TCP CHAT SERVER - 03/09/26

import socket
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.bind(("localhost",5000))

s.listen(5)
print("Server is Waiting for Connection .....")
c,addr=s.accept()
print("Got Connection From :",addr)

while True:
    data=c.recv(1024).decode()
    if data.lower() == "bye":
        print("Client Ended Chat!!!")
        break
    print("Client :",data)
    m=input("SERVER :")
    c.send(m.encode())

    if m.lower() == "bye":
        print("Chat Ended !!!")
        break

c.close()
s.close()
