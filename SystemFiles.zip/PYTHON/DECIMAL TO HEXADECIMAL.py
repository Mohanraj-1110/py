#DECIMAL TO HEXADECIMAL - 30/06/26

n=int(input("ENTER THE VALUE :"))
sum1=""
gnum=n
while(n!=0):
    r = n%16

    if(r==10):
        r="A"
    elif(r==11):
        r="B"
    elif(r==12):
        r="C"
    elif(r==13):
        r="D"
    elif(r==14):
        r="E"
    elif(r==15):
        r="F"
    else:
        r=str(r)
        
    sum1=r+sum1
    n//=16

print("GIVEN NUMBER :",gnum,"DECIMAL NUMBER :",sum1)
