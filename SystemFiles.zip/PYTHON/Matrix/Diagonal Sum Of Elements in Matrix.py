# DIAGONAL SUM OF ELEMENTS IN THE MATRIX- 17/07/26

lst=[]
n=int(input("Enter No. of rows :"))
m=int(input("Enter No. of columns :"))
for i in range(m):
    lst.append([])
    for j in range(n):
        x=int(input("Enter Element :"))
        lst[i].append(x)

print("Given Matrix :")
for i in lst:
    print(i)

d1sum=0
d2sum=0
for i in range(m):
    d1sum+=lst[i][i]
    d2sum+=lst[i][n-1-i]

print("Diagonal 1 Sum OF Elements in Matrix :",d1sum)
print("Diagonal 2 Sum OF Elements in Matrix :",d2sum)
