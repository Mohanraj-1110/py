#COUNT THE INDIVIDUAL DIGIT - 30/06/26

n=int(input("ENTER THE VALUE :"))
count=0
while(n!=0):
    count+=1
    n//=10

print("COUNT THE INDIVIDUAL DIGIT :",count)
