#CHECK THE GIVEN DATE IS VALID OR NOT - 25/06/26


d=int(input("ENTER DATE : "))
m=int(input("ENTER MONTH : "))
y=int(input("ENTER YEAR : "))

if m == 1 or m == 3 or m == 5 or m == 7 or m == 8 or m == 10 or m == 12 :
    maxd = 31
elif m == 4 or m == 6 or m == 9 or m == 11 :
    maxd = 30
else :
    if y % 4 == 0 and y % 100 != 0 or y % 400 == 0 :
        maxd = 29
    else :
        maxd = 28

if m >= 1 and m <= 12 and d >= 1 and d <= maxd :
    print(d,"/",m,"/",y," IS VALID DATE")
else :
    print(d,"/",m,"/",y," IS INVALID DATE")
