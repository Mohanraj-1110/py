# FIND THE NUMBER OF LINES, WORDS, AND CHARACTERS- 01/08/26

fn=input("Enter Filename :")
n_words = n_lines = n_chars = 0

with open(fn,"r")as f:
    for line in f:
        words=line.split(" ")
        print("Words :",words)
        n_words+=len(words)
        n_chars+=len(line)
        n_lines+=1


print("No. of Lines :",n_lines)
print("No. of Words :",n_words)
print("No. of Characters :",n_chars)
