# FILE MERGE- 01/08/26

with open ("file11.txt","w")as f1:
    n=int(input("Enter No.of Records :"))
    for i in range (n):
        x=input("Enter File Content :")
        f1.write(x+"\n")

with open ("file22.txt","w")as f2:
    n=int(input("Enter No.of Records :"))
    for i in range (n):
        x=input("Enter File Content :")
        f2.write(x+"\n")


with open("file11.txt","r")as f3:
    with open ("file33.txt","w")as f4:
        for line in f3:
            f4.write(line)

with open("file22.txt","r")as f5:
    with open ("file33.txt","a")as f6:
        for line in f5:
            f6.write(line)


print("Content of Merged File !!!")
with open("file33.txt","r")as f7:
    print(f7.read())
