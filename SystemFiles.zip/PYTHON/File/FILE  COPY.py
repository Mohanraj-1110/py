# FILE COPY- 01/08/26

with open ("fileold.txt","w")as f1:
    n=int(input("Enter No.of Records :"))
    for i in range (n):
        x=input("Enter File Content :")
        f1.write(x+"\n")

with open("fileold.txt","r")as f2:
    with open ("filenew.txt","w")as f3:
        for line in f2:
            f3.write(line)
print("Content of New File !!!")
with open("filenew.txt","r")as f4:
    print(f4.read())
