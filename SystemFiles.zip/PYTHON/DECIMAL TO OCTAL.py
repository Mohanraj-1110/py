#DECIMAL TO OCTAL - 30/06/26

n=int(input("ENTER THE VALUE :"))
sum1=""
gnum=n
while(n!=0):
    r = n%8
    sum1=str(r)+sum1
    n//=8

print("GIVEN NUMBER :",gnum,"OCTAL NUMBER :",sum1)
