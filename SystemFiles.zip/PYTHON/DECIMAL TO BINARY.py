#DECIMAL TO BINARY - 30/06/26

n=int(input("ENTER THE VALUE :"))
sum1=""
gnum=n
while(n!=0):
    r = n%2
    sum1=str(r)+sum1
    n//=2

print("GIVEN NUMBER :",gnum,"BINARY NUMBER :",sum1)
