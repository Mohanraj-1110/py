# METHOD OVERRIDING - 07/08/26

class shape:
    def inputSide(self):
        self.a=float(input("Enter Side :"))
        self.b=float(input("Enter Side :"))
        self.c=float(input("Enter Side :"))

    def dispSides(self):
        print("Side a:",self.a)
        print("Side b:",self.b)
        print("Side c:",self.c)

    def findArea(self):
        pass

class Triangle(shape):
    def findArea(self):
        s=(self.a+self.b+self.c)/2
        area=(s*(s-self.a)*(s-self.b)*(s-self.c))**0.5
        print("The Area of Triangle :",area)

class Rectangle(shape):
    def findArea(self):
        area=self.a*self.b
        print("The Area of Rectangle :",area)


t=Triangle()
t.inputSide()
t.dispSides()
t.findArea()

r=Rectangle()
r.inputSide()
r.dispSides()
r.findArea()
