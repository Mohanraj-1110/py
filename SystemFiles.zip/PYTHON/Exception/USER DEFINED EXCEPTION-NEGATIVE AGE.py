# USER DEFINED EXCEPTION : NEGATIVE AGE - 01/08/26

class NegativeAgeError(Exception):
    pass

try:
    x=int(input("Enter Age :"))
    if(x<0):
        raise NegativeAgeError
    print("Positive Value :",x)

except NegativeAgeError:
    print("Negative Age Eror :",x)

else:
    print("Successfully Completed !!!")

finally:
    print("Age Value Is Must !!!")
