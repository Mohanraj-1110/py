# USER DEFINED EXCEPTION : MOBILE NUMBER VALIDATION - 01/08/26

class MobileNumberError(Exception):
    pass

try:
    x=input("Enter Mobile Number :")
    if((len(x) != 10) or (not x.isdigit())):
        raise MobileNumberError
    
    print("Valid  Mobile Number :",x)

except MobileNumberError:
    print("Invalid Mobile Number :",x)

else:
    print("Successfully Completed !!!")

finally:
    print("Mobile Number must have 10 digits !!!")
