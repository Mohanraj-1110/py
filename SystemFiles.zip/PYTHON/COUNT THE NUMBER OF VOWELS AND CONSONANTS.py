# COUNT THE NUMBER OF VOWELS AND CONSONANTS- 24/07/26

s=input("Enter String :")
c1=0
c2=0
c3=0
v="aeiouAEIOU"

for i in s:
    if i in v:
        print("VOWEL :",i)
        c1+=1
    else :
        print("CONSONANT :",i)
        c2+=1
        

print("No. of Vowels are :",c1)
print("No. of Consonents are :",c2)
